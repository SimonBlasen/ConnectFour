package de.cogsys.ai.sogo.gui;


/**
 * @author Sebastian Otte
 */
public interface SogoGamePanelListener {
    public void clickedCell(final int i, final int j);
}