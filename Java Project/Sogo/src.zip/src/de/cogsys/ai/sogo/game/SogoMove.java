package de.cogsys.ai.sogo.game;

public class SogoMove {
	public int i;
	public int j;
	
	public SogoMove(int i, int j) {
		this.i = i;
		this.j = j;
	}
}
